local QBCore = nil
local ESX = nil
local activeSessions = {}

Citizen.CreateThread(function()
    if Config.Framework == 'QB' then
        QBCore = exports['qb-core']:GetCoreObject()
    elseif Config.Framework == 'ESX' then
        if exports['es_extended'] and exports['es_extended'].getSharedObject then
            ESX = exports['es_extended']:getSharedObject()
        else
            while ESX == nil do
                TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
                Citizen.Wait(0)
            end
        end
    end
    
    InitDatabase()
end)

function InitDatabase()
    if Config.Database.useMySQL then
        local query = [[
            CREATE TABLE IF NOT EXISTS `duty_logs` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `identifier` VARCHAR(50) NOT NULL,
                `player_name` VARCHAR(50) NOT NULL,
                `job` VARCHAR(50) NOT NULL,
                `total_time` INT DEFAULT 0,
                `last_duty_start` INT DEFAULT NULL,
                `last_duty_end` INT DEFAULT NULL,
                UNIQUE KEY `unique_player_job` (`identifier`, `job`),
                INDEX `idx_identifier` (`identifier`),
                INDEX `idx_job` (`job`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            
            CREATE TABLE IF NOT EXISTS `duty_logs_history` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `identifier` VARCHAR(50) NOT NULL,
                `player_name` VARCHAR(50) NOT NULL,
                `job` VARCHAR(50) NOT NULL,
                `session_start` INT NOT NULL,
                `session_end` INT NOT NULL,
                `session_duration` INT NOT NULL,
                `timestamp` INT NOT NULL,
                INDEX `idx_identifier` (`identifier`),
                INDEX `idx_job` (`job`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ]]
        
        if Config.Database.export == 'oxmysql' then
            exports.oxmysql:query(query, {}, function()
                print("[DutyLog] Database tables initialized (oxmysql)")
            end)
        else
            MySQL.query(query, {}, function()
                print("[DutyLog] Database tables initialized (mysql-async)")
            end)
        end
    end
end

local function GetIdentifier(source)
    if Config.Framework == 'QB' then
        local pData = QBCore and QBCore.Functions.GetPlayer(source)
        return pData and pData.PlayerData and pData.PlayerData.citizenid or nil
    elseif Config.Framework == 'ESX' then
        local xPlayer = ESX and ESX.GetPlayerFromId(source)
        return xPlayer and xPlayer.getIdentifier() or nil
    end
    return nil
end

local function GetPlayerJob(source)
    local job = nil
    if Config.Framework == 'QB' then
        local pData = QBCore and QBCore.Functions.GetPlayer(source)
        job = pData and pData.PlayerData and pData.PlayerData.job and pData.PlayerData.job.name
    elseif Config.Framework == 'ESX' then
        local xPlayer = ESX and ESX.GetPlayerFromId(source)
        job = xPlayer and xPlayer.job and xPlayer.job.name
    end
    return job and string.lower(job) or nil
end

local function FormatDuration(seconds)
    if not seconds then return "00:00:00" end
    local hours = math.floor(seconds / 3600)
    local minutes = math.floor((seconds % 3600) / 60)
    local secs = seconds % 60
    return string.format("%02d:%02d:%02d", hours, minutes, secs)
end

local function SendToDiscord(jobName, title, description, color)
    local jobConfig = Config.TrackedJobs[jobName]
    if not jobConfig or not jobConfig.webhook or jobConfig.webhook == "YOUR_WEBHOOK_HERE" or jobConfig.webhook == "" then 
        return 
    end
    
    local embed = {
        {
            ["color"] = color or jobConfig.color,
            ["title"] = title,
            ["description"] = description,
            ["footer"] = {
                ["text"] = "Duty Log System • " .. os.date(Config.DateFormat)
            }
        }
    }
    
    PerformHttpRequest(jobConfig.webhook, function(err, text, headers) end, 'POST', json.encode({username = "Duty Logger", embeds = embed}), {['Content-Type'] = 'application/json'})
end

local function UpdateDatabase(identifier, playerName, job, totalTime, dutyStart)
    if not Config.Database.useMySQL then return end
    
    local query = [[
        INSERT INTO duty_logs (identifier, player_name, job, total_time, last_duty_start)
        VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            player_name = VALUES(player_name),
            total_time = VALUES(total_time),
            last_duty_start = VALUES(last_duty_start)
    ]]
    
    local params = {identifier, playerName, job, totalTime, dutyStart}
    
    if Config.Database.export == 'oxmysql' then
        exports.oxmysql:insert(query, params)
    else
        MySQL.insert(query, params)
    end
end

local function EndDatabaseSession(identifier, playerName, job, sessionStart, sessionEnd, duration)
    if not Config.Database.useMySQL then return end
    
    local historyQuery = [[
        INSERT INTO duty_logs_history (identifier, player_name, job, session_start, session_end, session_duration, timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ]]
    local historyParams = {identifier, playerName, job, sessionStart, sessionEnd, duration, os.time()}
    
    if Config.Database.export == 'oxmysql' then
        exports.oxmysql:insert(historyQuery, historyParams)
    else
        MySQL.insert(historyQuery, historyParams)
    end
end

local function GetTotalTimeFromDB(identifier, job, cb)
    if not Config.Database.useMySQL then
        cb(0)
        return
    end
    
    local query = "SELECT total_time FROM duty_logs WHERE identifier = ? AND job = ?"
    
    if Config.Database.export == 'oxmysql' then
        exports.oxmysql:scalar(query, {identifier, job}, function(result)
            cb(result or 0)
        end)
    else
        MySQL.scalar(query, {identifier, job}, function(result)
            cb(result or 0)
        end)
    end
end

local function HandleDutyStart(source, job)
    if not Config.TrackedJobs[job] then return end
    
    local identifier = GetIdentifier(source)
    if not identifier then return end
    
    if activeSessions[identifier] then return end
    
    activeSessions[identifier] = {
        startTime = os.time(),
        job = job,
        source = source
    }
    
    local playerName = GetPlayerName(source)
    local jobLabel = Config.TrackedJobs[job].label
    
    GetTotalTimeFromDB(identifier, job, function(totalTime)
        UpdateDatabase(identifier, playerName, job, totalTime, os.time())
    end)
    
    local embedDesc = string.format("**👤 Player:** %s\n**🆔 ID:** %s\n**💼 Job:** %s\n**🕐 Status:** ON DUTY\n**📊 Total Time:** %s", 
        playerName, identifier, jobLabel, FormatDuration(0))
    
    SendToDiscord(job, "📋 Duty Started - " .. jobLabel, embedDesc, Config.TrackedJobs[job].color)
end

local function HandleDutyEnd(source, job)
    local identifier = GetIdentifier(source)
    if not identifier or not activeSessions[identifier] or activeSessions[identifier].job ~= job then return end
    
    local sessionData = activeSessions[identifier]
    local endTime = os.time()
    local duration = endTime - sessionData.startTime
    
    local playerName = GetPlayerName(source)
    local jobLabel = Config.TrackedJobs[job] and Config.TrackedJobs[job].label or job
    
    GetTotalTimeFromDB(identifier, job, function(currentTotal)
        local newTotal = currentTotal + duration
        UpdateDatabase(identifier, playerName, job, newTotal, nil)
        EndDatabaseSession(identifier, playerName, job, sessionData.startTime, endTime, duration)
        
        local embedDesc = string.format("**👤 Player:** %s\n**🆔 ID:** %s\n**💼 Job:** %s\n**🕐 Status:** OFF DUTY\n**⏱️ Session:** %s\n**📊 Total Time:** %s", 
            playerName, identifier, jobLabel, FormatDuration(duration), FormatDuration(newTotal))
        
        SendToDiscord(job, "✅ Duty Ended - " .. jobLabel, embedDesc, 15158332)
    end)
    
    activeSessions[identifier] = nil
end

if Config.Framework == 'QB' then
    RegisterNetEvent('QBCore:Server:PlayerLoaded', function(Player)
        if Player and Player.PlayerData and Player.PlayerData.job then
            HandleDutyStart(Player.PlayerData.source, Player.PlayerData.job.name)
        end
    end)
    
    RegisterNetEvent('QBCore:Server:OnJobUpdate', function(Player, Job)
        local identifier = Player.PlayerData.citizenid
        local source = Player.PlayerData.source
        
        if activeSessions[identifier] then
            HandleDutyEnd(source, activeSessions[identifier].job)
        end
        
        if Job and Job.name then
            HandleDutyStart(source, Job.name)
        end
    end)

elseif Config.Framework == 'ESX' then
    AddEventHandler('esx:playerLoaded', function(...)
        local args = {...}
        local source, xPlayer
        
        if type(args[1]) == 'number' then
            source = args[1]
            xPlayer = args[2]
        else
            xPlayer = args[1]
            source = xPlayer and xPlayer.source
        end
        
        if xPlayer and xPlayer.job and source then
            HandleDutyStart(source, xPlayer.job.name)
        end
    end)
    
    AddEventHandler('esx:setJob', function(...)
        local args = {...}
        local source, job, lastJob
        
        if type(args[1]) == 'number' then
            source = args[1]
            job = args[2]
            lastJob = args[3]
        else
            job = args[1]
            lastJob = args[2]
            local xPlayer = ESX.GetPlayerFromId(source)
            source = xPlayer and xPlayer.source or source
        end
        
        if job and job.name then
            if activeSessions[GetIdentifier(source)] then
                HandleDutyEnd(source, activeSessions[GetIdentifier(source)].job)
            end
            HandleDutyStart(source, job.name)
        end
    end)
end

AddEventHandler('playerDropped', function()
    local source = source
    local identifier = GetIdentifier(source)
    
    if identifier and activeSessions[identifier] then
        HandleDutyEnd(source, activeSessions[identifier].job)
    end
end)

RegisterCommand('worktime', function(source, args, rawCommand)
    local targetId = tonumber(args[1]) or source
    if targetId == 0 then return end

    local identifier = GetIdentifier(targetId)
    if not identifier then 
        TriggerClientEvent('chat:addMessage', source, { args = { "^1Player not found." } })
        return 
    end

    local query = "SELECT player_name, job, total_time FROM duty_logs WHERE identifier = ?"
    
    if Config.Database.export == 'oxmysql' then
        exports.oxmysql:fetch(query, {identifier}, function(results)
            if results and #results > 0 then
                local msg = "^2[Duty Log] Work Times for " .. GetPlayerName(targetId) .. ":^7\n"
                for _, row in ipairs(results) do
                    local label = Config.TrackedJobs[row.job] and Config.TrackedJobs[row.job].label or row.job
                    msg = msg .. "  📋 " .. label .. ": ^3" .. FormatDuration(row.total_time) .. "^7\n"
                end
                TriggerClientEvent('chat:addMessage', source, { args = { msg } })
            else
                TriggerClientEvent('chat:addMessage', source, { args = { "^1No work time recorded for this player." } })
            end
        end)
    else
        MySQL.query(query, {identifier}, function(results)
            if results and #results > 0 then
                local msg = "^2[Duty Log] Work Times for " .. GetPlayerName(targetId) .. ":^7\n"
                for _, row in ipairs(results) do
                    local label = Config.TrackedJobs[row.job] and Config.TrackedJobs[row.job].label or row.job
                    msg = msg .. "  📋 " .. label .. ": ^3" .. FormatDuration(row.total_time) .. "^7\n"
                end
                TriggerClientEvent('chat:addMessage', source, { args = { msg } })
            else
                TriggerClientEvent('chat:addMessage', source, { args = { "^1No work time recorded for this player." } })
            end
        end)
    end
end, true)

RegisterCommand('alldutytime', function(source, args, rawCommand)
    if source == 0 then return end

    local jobFilter = args[1] and string.lower(args[1]) or nil
    
    local query
    local params = {}
    
    if jobFilter then
        query = "SELECT player_name, job, total_time FROM duty_logs WHERE job = ? ORDER BY total_time DESC LIMIT 20"
        params = {jobFilter}
    else
        query = "SELECT player_name, job, total_time FROM duty_logs ORDER BY total_time DESC LIMIT 20"
    end
    
    if Config.Database.export == 'oxmysql' then
        exports.oxmysql:fetch(query, params, function(results)
            if results and #results > 0 then
                local jobLabel = jobFilter and (Config.TrackedJobs[jobFilter] and Config.TrackedJobs[jobFilter].label or jobFilter) or "All Jobs"
                local msg = "^2[Duty Log] Top Workers - " .. jobLabel .. ":^7\n"
                for i, row in ipairs(results) do
                    local label = Config.TrackedJobs[row.job] and Config.TrackedJobs[row.job].label or row.job
                    msg = msg .. string.format("  %d. ^6%s^7 (%s): ^3%s^7\n", i, row.player_name, label, FormatDuration(row.total_time))
                end
                TriggerClientEvent('chat:addMessage', source, { args = { msg } })
            else
                TriggerClientEvent('chat:addMessage', source, { args = { "^1No work time records found." } })
            end
        end)
    else
        MySQL.query(query, params, function(results)
            if results and #results > 0 then
                local jobLabel = jobFilter and (Config.TrackedJobs[jobFilter] and Config.TrackedJobs[jobFilter].label or jobFilter) or "All Jobs"
                local msg = "^2[Duty Log] Top Workers - " .. jobLabel .. ":^7\n"
                for i, row in ipairs(results) do
                    local label = Config.TrackedJobs[row.job] and Config.TrackedJobs[row.job].label or row.job
                    msg = msg .. string.format("  %d. ^6%s^7 (%s): ^3%s^7\n", i, row.player_name, label, FormatDuration(row.total_time))
                end
                TriggerClientEvent('chat:addMessage', source, { args = { msg } })
            else
                TriggerClientEvent('chat:addMessage', source, { args = { "^1No work time records found." } })
            end
        end)
    end
end, true)

RegisterNetEvent('duty_log:server:checkMyStatus', function()
    local source = source
    local identifier = GetIdentifier(source)
    local job = GetPlayerJob(source)
    
    if not job or not Config.TrackedJobs[job] then
        TriggerClientEvent('chat:addMessage', source, { args = { "^1Your job is not tracked." } })
        return
    end
    
    local isOnDuty = activeSessions[identifier] ~= nil
    local sessionTime = 0
    local totalTime = 0
    
    local query = "SELECT total_time FROM duty_logs WHERE identifier = ? AND job = ?"
    
    if Config.Database.export == 'oxmysql' then
        exports.oxmysql:scalar(query, {identifier, job}, function(result)
            totalTime = result or 0
            if isOnDuty then
                sessionTime = os.time() - activeSessions[identifier].startTime
                totalTime = totalTime + sessionTime
            end
            TriggerClientEvent('duty_log:client:receiveStatus', source, isOnDuty, job, FormatDuration(sessionTime), FormatDuration(totalTime))
        end)
    else
        MySQL.scalar(query, {identifier, job}, function(result)
            totalTime = result or 0
            if isOnDuty then
                sessionTime = os.time() - activeSessions[identifier].startTime
                totalTime = totalTime + sessionTime
            end
            TriggerClientEvent('duty_log:client:receiveStatus', source, isOnDuty, job, FormatDuration(sessionTime), FormatDuration(totalTime))
        end)
    end
end)

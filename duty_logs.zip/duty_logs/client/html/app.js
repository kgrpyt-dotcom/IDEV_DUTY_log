// Duty Log UI Controller
let isOnDuty = false;
let currentJob = null;
let workTime = 0;
let totalTime = 0;
let sessionStartTime = 0;

// Format seconds to HH:MM:SS
function formatTime(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

// Update the UI based on current state
function updateUI(data) {
    if (data.isOnDuty !== undefined) isOnDuty = data.isOnDuty;
    if (data.job) currentJob = data.job;
    if (data.workTime !== undefined) workTime = data.workTime;
    if (data.totalTime !== undefined) totalTime = data.totalTime;

    const statusCard = document.getElementById('status-card');
    const dutyStatusText = document.getElementById('duty-status-text');
    const jobLabel = document.getElementById('job-label');
    const workTimeEl = document.getElementById('work-time');
    const dutyToggle = document.getElementById('duty-toggle');
    const toggleText = document.getElementById('toggle-text');
    const sessionTimeEl = document.getElementById('session-time');
    const totalTimeEl = document.getElementById('total-time');

    // Update status card
    if (isOnDuty) {
        statusCard.classList.add('on-duty');
        dutyStatusText.textContent = 'ON DUTY';
        toggleText.textContent = 'Clock Out';
        dutyToggle.classList.add('active');
    } else {
        statusCard.classList.remove('on-duty');
        dutyStatusText.textContent = 'OFF DUTY';
        toggleText.textContent = 'Clock In';
        dutyToggle.classList.remove('active');
    }

    // Update job label
    if (data.jobLabel) {
        jobLabel.textContent = data.jobLabel;
    }

    // Update times
    workTimeEl.textContent = formatTime(workTime);
    sessionTimeEl.textContent = formatTime(workTime);
    totalTimeEl.textContent = formatTime(totalTime || workTime);

    // Update job-specific styling
    document.getElementById('duty-log-app').className = 'job-' + (currentJob || 'default');

    // Update info panel
    if (data.playerId) {
        document.getElementById('player-id').textContent = data.playerId;
    }
    if (data.jobLabel) {
        document.getElementById('job-type').textContent = data.jobLabel;
    }
}

// Toggle duty status
function toggleDuty() {
    const newDutyState = !isOnDuty;
    
    fetch(`https://${GetParentResourceName()}/toggleDuty`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isOnDuty: newDutyState })
    }).then(() => {
        isOnDuty = newDutyState;
        if (isOnDuty) {
            sessionStartTime = Date.now();
        }
        updateUI({ isOnDuty: isOnDuty });
    }).catch(err => console.error('Error toggling duty:', err));
}

// Close UI
function closeUI() {
    fetch(`https://${GetParentResourceName()}/closeUI`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    }).catch(err => console.error('Error closing UI:', err));
}

// Show notification toast
function showNotification(title, message, job, type = 'info') {
    const toast = document.getElementById('notification-toast');
    const toastTitle = document.getElementById('toast-title');
    const toastMessage = document.getElementById('toast-message');
    const toastIcon = document.getElementById('toast-icon');

    toastTitle.textContent = title;
    toastMessage.textContent = message;
    
    toast.className = 'notification-toast ' + type;
    
    if (type === 'success') {
        toastIcon.innerHTML = '<i class="fas fa-check"></i>';
    } else if (type === 'warning') {
        toastIcon.innerHTML = '<i class="fas fa-exclamation"></i>';
    } else {
        toastIcon.innerHTML = '<i class="fas fa-bell"></i>';
    }

    toast.classList.add('show');

    // Auto-hide after 5 seconds
    setTimeout(() => {
        hideNotification();
    }, 5000);
}

// Hide notification toast
function hideNotification() {
    const toast = document.getElementById('notification-toast');
    toast.classList.remove('show');
}

// Listen for NUI messages from Lua
window.addEventListener('message', function(event) {
    const data = event.data;

    if (data.type === 'updateUI') {
        updateUI(data);
    } else if (data.type === 'notification') {
        showNotification(data.title, data.message, data.job, data.type || 'info');
    }
});

// Handle keyboard events
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeUI();
    }
});

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    console.log('[Duty Log] UI Initialized');
    
    // Request initial data from server
    fetch(`https://${GetParentResourceName()}/requestData`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    }).catch(err => console.error('Error requesting data:', err));
});

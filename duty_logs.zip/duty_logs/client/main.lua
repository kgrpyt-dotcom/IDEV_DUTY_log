-- Client-side duty log (Automatic - No UI Toggle)
-- All duty tracking is handled automatically by the server based on job status
-- Discord logging is server-side only

local QBCore = nil
local ESX = nil

-- Initialize Framework
Citizen.CreateThread(function()
    if Config.Framework == 'QB' then
        QBCore = exports['qb-core']:GetCoreObject()
    elseif Config.Framework == 'ESX' then
        if exports['es_extended'] and exports['es_extended'].getSharedObject then
            ESX = exports['es_extended']:getSharedObject()
        else
            while ESX == nil do
                TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
                Citizen.Wait(0)
            end
        end
    end
end)

-- Optional: Simple chat command to check status
RegisterCommand('dutystatus', function()
    TriggerServerEvent('duty_log:server:checkMyStatus')
end)

-- Listen for status response from server
RegisterNetEvent('duty_log:client:receiveStatus', function(isOnDuty, job, sessionTime, totalTime)
    local status = isOnDuty and '^2ON DUTY^7' or '^1OFF DUTY^7'
    local jobLabel = Config.TrackedJobs[job] and Config.TrackedJobs[job].label or job
    
    TriggerEvent('chat:addMessage', {
        template = '<div style="padding: 8px; margin: 5px 0; background: rgba(0,0,0,0.3); border-radius: 5px;"><b>📋 Duty Status</b><br>Job: ' .. jobLabel .. '<br>Status: ' .. status .. '<br>Session: ' .. sessionTime .. '<br>Total: ' .. totalTime .. '</div>',
        args = {}
    })
end)

-- Show notification when duty changes
RegisterNetEvent('duty_log:client:notification', function(title, message)
    SetNotificationTextEntry('STRING')
    AddTextComponentString(message)
    DrawNotification(false, true)
end)

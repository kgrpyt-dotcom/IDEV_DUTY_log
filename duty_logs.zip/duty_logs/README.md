# Duty Log System for FiveM

Automatic duty logging system with MySQL database support for tracking Police, EMS, and Admin work time.

## Features

- **Fully Automatic** - No UI needed. Duty tracked automatically when players join/leave or change jobs
- **Discord Integration** - Rich embeds sent to Discord when players clock in/out
- **MySQL Database** - All work times stored in MySQL for permanent records
- **Work Time Tracking** - Tracks session time and total accumulated time per player
- **Leaderboard** - See top workers across all jobs
- **History Logs** - Every session is logged with timestamps
- **Multi-Framework** - Supports both QBCore and ESX

## Database Setup

### Automatic (Recommended)

The script will automatically create the required tables on first start.

### Manual SQL

If you want to create tables manually:

```sql
CREATE TABLE IF NOT EXISTS `duty_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `identifier` VARCHAR(50) NOT NULL,
    `player_name` VARCHAR(50) NOT NULL,
    `job` VARCHAR(50) NOT NULL,
    `total_time` INT DEFAULT 0,
    `last_duty_start` INT DEFAULT NULL,
    `last_duty_end` INT DEFAULT NULL,
    UNIQUE KEY `unique_player_job` (`identifier`, `job`),
    INDEX `idx_identifier` (`identifier`),
    INDEX `idx_job` (`job`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `duty_logs_history` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `identifier` VARCHAR(50) NOT NULL,
    `player_name` VARCHAR(50) NOT NULL,
    `job` VARCHAR(50) NOT NULL,
    `session_start` INT NOT NULL,
    `session_end` INT NOT NULL,
    `session_duration` INT NOT NULL,
    `timestamp` INT NOT NULL,
    INDEX `idx_identifier` (`identifier`),
    INDEX `idx_job` (`job`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

## Installation

1. Place the `duty_logs` folder in your server's `resources` directory
2. Set `Config.Framework` to `'QB'` or `'ESX'` in `config.lua`
3. Set `Config.Database.useMySQL` to `true`
4. Set `Config.Database.export` to `'oxmysql'` or `'mysql-async'` (depending on your server's MySQL library)
5. Add your Discord webhook URLs for each job
6. Add `ensure duty_logs` to your `server.cfg`

## Configuration

```lua
Config.Framework = 'ESX'

Config.Database = {
    useMySQL = true,
    export = 'oxmysql' -- or 'mysql-async'
}

Config.TrackedJobs = {
    ['police'] = {
        label = "Police Department",
        webhook = "YOUR_WEBHOOK_URL",
        color = 3447003
    },
    ['ambulance'] = {
        label = "EMS / Medical Services",
        webhook = "YOUR_WEBHOOK_URL",
        color = 15158332
    },
    ['admin'] = {
        label = "Admin / Staff",
        webhook = "YOUR_WEBHOOK_URL",
        color = 15844367
    }
}
```

## Commands

- `/dutystatus` - Check your current duty status and work times
- `/worktime [id]` - Check total work time for a player (admin only)
- `/alldutytime [job]` - View top 20 workers (all jobs or filter by job name like `police`)

## Database Tables

### `duty_logs` - Current totals
| Column | Description |
|--------|-------------|
| identifier | Player's unique identifier |
| player_name | Current player name |
| job | Job name (police, ambulance, admin) |
| total_time | Total accumulated time in seconds |
| last_duty_start | Unix timestamp of last clock in |

### `duty_logs_history` - Session history
| Column | Description |
|--------|-------------|
| identifier | Player's unique identifier |
| player_name | Player name at time of session |
| job | Job name |
| session_start | Unix timestamp when duty started |
| session_end | Unix timestamp when duty ended |
| session_duration | Duration in seconds |
| timestamp | When the record was created |

## How It Works

1. Player with tracked job **joins server** → Duty starts, Discord notification sent
2. Player **leaves** or **changes job** → Duty ends, session logged to DB, Discord shows session + total time
3. All sessions logged in `duty_logs_history` for complete records

fx_version 'cerulean'
game 'gta5'

author 'Ivan'
description 'Duty log system for FiveM (Police, EMS, Admin)'
version '1.0.0'

shared_script 'config.lua'
server_script 'server/main.lua'
client_script 'client/main.lua'

Config = {}

Config.Framework = 'ESX'

Config.TrackedJobs = {
    ['police'] = {
        label = "Police Department",
        webhook = "YOUR_WEBHOOK_HERE",
        color = 3447003
    },
    ['ambulance'] = {
        label = "EMS / Medical Services",
        webhook = "YOUR_WEBHOOK_HERE",
        color = 15158332
    },
    ['admin'] = {
        label = "Admin / Staff",
        webhook = "YOUR_WEBHOOK_HERE",
        color = 15844367
    }
}

Config.DateFormat = "%Y-%m-%d %H:%M:%S"

Config.Database = {
    useMySQL = true,
    useJSONFallback = false,
    export = 'oxmysql' -- 'oxmysql' or 'mysql-async'
}

Config.SavePath = 'server/work_times.json'
